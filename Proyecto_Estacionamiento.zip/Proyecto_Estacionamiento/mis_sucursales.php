<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: inicio_sesion.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido'];

// Consulta para obtener las sucursales, su ubicación y los espacios disponibles, además del costo total de autos
$sql = "SELECT S.id, S.nombre, S.ubicacion, S.espacios_disponibles, 
               COALESCE(SUM(E.costo), 0) AS costo_total_autos
        FROM Sucursales S
        LEFT JOIN Estacionamientos E ON S.id = E.sucursal_id
        GROUP BY S.id";
$result = $conexion->query($sql);

$sucursales = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sucursales[] = $row;
    }
} else {
    echo "No hay sucursales disponibles.";
}

$conexion->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Sucursales - ParkWise</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="proyecto/dashboard.css">
</head>
<body>
    <div class="d-flex" id="wrapper">

        <!-- Menú lateral -->
        <div class="bg-dark" id="sidebar-wrapper">
            <div class="sidebar-heading">
                <div class="logo-container">
                    <img src="img/logo.png" alt="ParkWise Logo" class="logo">
                </div>
            </div>
            <div class="list-group list-group-flush">
                <a href="dashboard.php" class="list-group-item list-group-item-action">Inicio</a>
                <a href="mis_sucursales.php" class="list-group-item list-group-item-action">Mis Sucursales</a>
                <a href="estacionamientos.php" class="list-group-item list-group-item-action">Estacionamientos</a>
                <a href="precios.php" class="list-group-item list-group-item-action">Precios</a>
                <a href="reportes.php" class="list-group-item list-group-item-action">Reportes</a>
                <a href="#" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#logoutModal">Cerrar Sesión</a>
                <img src="img/sky_dancer.gif" class="sky_dancer" alt="Sky Dancer">
            </div>
        </div>

        <!-- Contenido principal -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg">
                <div class="container-fluid">
                    <h1 class="navbar-brand">ParkWise</h1>
                    <div class="ml-auto">
                        <div class="card" style="width: 300px;">
                            <div class="card-body d-flex align-items-center">
                                <img src="img/usuario.png" alt="Usuario" class="img-fluid rounded-circle" style="width: 50px; height: 50px; margin-right: 10px;">
                                <h5 class="card-title mb-0"><?php echo "Hola, <br> $nombre $apellido" ?></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            <div class="container-fluid">
                <h1 class="mt-4">Mis Sucursales</h1>
                <button class="btn btn-outline-custom" data-toggle="modal" data-target="#createModal">Crear Sucursal</button>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nombre de la Sucursal</th>
                            <th>Ubicación</th>
                            <th>Espacios Disponibles</th>
                            <th>Costo Total de Autos</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sucursales as $sucursal): ?>
                            <tr>
                                <td><?php echo $sucursal['nombre']; ?></td>
                                <td><?php echo $sucursal['ubicacion']; ?></td>
                                <td><?php echo $sucursal['espacios_disponibles']; ?></td>
                                <td><?php echo "$" . number_format($sucursal['costo_total_autos'], 2); ?></td>
                                <td>
                                    <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editModal" 
                                            data-id="<?php echo $sucursal['id']; ?>" 
                                            data-nombre="<?php echo $sucursal['nombre']; ?>" 
                                            data-ubicacion="<?php echo $sucursal['ubicacion']; ?>" 
                                            data-espacios="<?php echo $sucursal['espacios_disponibles']; ?>">
                                        Editar
                                    </button>
                                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal" 
                                        data-id="<?php echo $sucursal['id']; ?>" 
                                        data-nombre="<?php echo $sucursal['nombre']; ?>">
                                        Eliminar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Modal de edición de sucursal -->
        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="actualizar_sucursal.php" method="post">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel">Editar Sucursal</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" id="sucursal-id">
                            <div class="form-group">
                                <label for="sucursal-nombre">Nombre</label>
                                <input type="text" class="form-control" name="nombre" id="sucursal-nombre" required>
                            </div>
                            <div class="form-group">
                                <label for="sucursal-ubicacion">Ubicación</label>
                                <input type="text" class="form-control" name="ubicacion" id="sucursal-ubicacion" required>
                            </div>
                            <div class="form-group">
                                <label for="sucursal-espacios">Espacios Disponibles</label>
                                <input type="number" class="form-control" name="espacios" id="sucursal-espacios" required min="0" max="500">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-outline-custom">Guardar cambios</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal para Crear Sucursal -->
        <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="crear_sucursal.php" method="post">
                        <div class="modal-header">
                            <h5 class="modal-title" id="createModalLabel">Crear Nueva Sucursal</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="nuevo-nombre">Nombre</label>
                                <input type="text" class="form-control" name="nombre" id="nuevo-nombre" required>
                            </div>
                            <div class="form-group">
                                <label for="nueva-ubicacion">Ubicación</label>
                                <input type="text" class="form-control" name="ubicacion" id="nueva-ubicacion" required>
                            </div>
                            <div class="form-group">
                                <label for="nuevos-espacios">Espacios Disponibles</label>
                                <input type="number" class="form-control" name="espacios" id="nuevos-espacios" required min="0" max="500">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-outline-custom">Crear Sucursal</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal para Confirmar Eliminación -->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="eliminar_sucursal.php" method="post">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLabel">Eliminar Sucursal</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" id="sucursal-id-eliminar">
                            <p>¿Estás seguro de que deseas eliminar la sucursal <strong id="sucursal-nombre-eliminar"></strong>?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-outline-custom">Eliminar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal de confirmación de cierre de sesión -->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="logoutModalLabel">¿Seguro que quieres cerrar sesión?</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Haz clic en "Cerrar Sesión" si estás listo para terminar tu sesión actual.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                        <a href="logout.php" class="btn btn-outline-custom">Cerrar Sesión</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts de Bootstrap y JavaScript para el modal -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $('#editModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            $('#sucursal-id').val(button.data('id'));
            $('#sucursal-nombre').val(button.data('nombre'));
            $('#sucursal-ubicacion').val(button.data('ubicacion'));
            $('#sucursal-espacios').val(button.data('espacios'));
        });
    </script>
    <script>
        $('#deleteModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            $('#sucursal-id-eliminar').val(button.data('id'));
            $('#sucursal-nombre-eliminar').text(button.data('nombre'));
        });
    </script>
</body>
</html>
