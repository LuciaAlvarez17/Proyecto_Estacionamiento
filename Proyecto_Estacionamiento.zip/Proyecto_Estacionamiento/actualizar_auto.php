<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: inicio_sesion.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $tipoVehiculo = $_POST['tipoVehiculo'];
    $marcaModelo = $_POST['marcaModelo'];
    $horaSalida = $_POST['horaSalida'];
    $estado = $_POST['estado'];

    $stmt = $conexion->prepare("UPDATE Estacionamientos SET tipo_vehiculo = ?, marca_modelo = ?, hora_salida = ?, estado = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $tipoVehiculo, $marcaModelo, $horaSalida, $estado, $id);

    if ($stmt->execute()) {
        $_SESSION['mensaje'] = "Auto actualizado correctamente.";
    } else {
        $_SESSION['mensaje'] = "Error al actualizar el auto: " . $stmt->error;
    }

    $stmt->close();
    $conexion->close();

    header('Location: estacionamientos.php');
    exit();
} else {
    header('Location: estacionamientos.php');
    exit();
}
?>