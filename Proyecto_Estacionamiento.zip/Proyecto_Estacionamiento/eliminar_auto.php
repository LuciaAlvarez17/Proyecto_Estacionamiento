<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: inicio_sesion.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    // Obtener el ID de la sucursal del auto que se va a actualizar
    $stmt = $conexion->prepare("SELECT sucursal_id FROM Estacionamientos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    if ($resultado->num_rows > 0) {
        $espacio = $resultado->fetch_assoc();
        $sucursal_id = $espacio['sucursal_id'];

        // Cambiar el estado del auto a 'vacío' en lugar de eliminarlo
        $stmt = $conexion->prepare("UPDATE Estacionamientos SET estado = 'vacío' WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            // Sumar un espacio a la sucursal
            $stmt = $conexion->prepare("UPDATE Sucursales SET espacios_disponibles = espacios_disponibles + 1 WHERE id = ?");
            $stmt->bind_param("i", $sucursal_id);
            $stmt->execute();
        }
    }

    $stmt->close();
    $conexion->close();

    header('Location: estacionamientos.php');
    exit();
} else {
    header('Location: estacionamientos.php');
    exit();
}
?>