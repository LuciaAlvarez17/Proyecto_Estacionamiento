<?php
session_start();
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del formulario
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $sucursales = intval($_POST['sucursales']);
    $espacios_sucursales = $_POST['espacios_sucursal'];

    // Iniciar transacción
    $conexion->begin_transaction();

    try {
        // Insertar el usuario
        $stmt = $conexion->prepare("INSERT INTO Usuarios (nombre, apellido, correo, contrasena, telefono) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nombre, $apellido, $correo, $password, $telefono);
        $stmt->execute();
        
        // Obtener el ID del usuario recién insertado
        $usuario_id = $conexion->insert_id;

        // Insertar sucursales
        foreach ($espacios_sucursales as $i => $espacios) {
            if ($espacios > 0 && $espacios <= 500) {
                $stmt = $conexion->prepare("INSERT INTO Sucursales (usuario_id, nombre, espacios_disponibles, ubicacion) VALUES (?, ?, ?, ?)");
                $nombre_sucursal = "Sucursal " . ($i + 1);
                $ubicacion = 'Ubicación ' . ($i + 1);
                $stmt->bind_param("isds", $usuario_id, $nombre_sucursal, $espacios, $ubicacion);
                $stmt->execute();
            }
        }

        $conexion->commit();

        $_SESSION['success'] = "Registro exitoso. Ahora puedes iniciar sesión.";
        header('Location: inicio_sesion.php');
        exit;

    } catch (Exception $e) {

        $conexion->rollback();
        $_SESSION['error'] = "Error al registrar: " . $e->getMessage();
        header('Location: registro.php');
        exit;
    } finally {
        $stmt->close();
    }
} else {
    header('Location: registro.php');
    exit;
}
?>