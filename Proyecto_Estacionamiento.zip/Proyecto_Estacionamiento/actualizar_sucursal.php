<?php
session_start();
include 'conexion.php';

if (isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['ubicacion']) && isset($_POST['espacios'])) {
    
    $id = $_POST['id'];
    $nombre = $conexion->real_escape_string($_POST['nombre']);
    $ubicacion = $conexion->real_escape_string($_POST['ubicacion']);
    $espacios = intval($_POST['espacios']);
    
    $sql = "UPDATE Sucursales SET nombre='$nombre', ubicacion='$ubicacion', espacios_disponibles=$espacios WHERE id=$id";
    
    if ($conexion->query($sql) === TRUE) {
        header("Location: mis_sucursales.php?mensaje=actualizado");
        exit();
    } else {
        echo "Error al actualizar la sucursal: " . $conexion->error;
    }
} else {
    echo "Datos incompletos.";
}

// Cerrar la conexión
$conexion->close();
?>
