<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: inicio_sesion.php');
    exit();
}

if (!empty($_POST['id'])) {
    $sucursal_id = $_POST['id'];
    $usuario_id = $_SESSION['usuario_id'];

    if (!is_numeric($sucursal_id)) {
        header('Location: mis_sucursales.php?mensaje=error_id_invalido');
        exit();
    }

    $sql = "DELETE FROM Sucursales WHERE id = ? AND usuario_id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("ii", $sucursal_id, $usuario_id);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        header('Location: mis_sucursales.php?mensaje=eliminado');
    } else {
        header('Location: mis_sucursales.php?mensaje=error_eliminar');
    }

    $stmt->close();
    $conexion->close();
} else {
    header('Location: mis_sucursales.php?mensaje=error_metodo_invalido');
}
exit();