<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ParkWise</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="inicio_sesion.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="logo-container">
                <img src="img/logo.png" alt="ParkWise Logo" class="logo">
            </div>
            <form action="iniciar_sesion.php" method="POST" onsubmit="return validateForm()">
                <label for="correo">Correo electrónico:</label>
                <input type="email" id="correo" name="correo" placeholder="Ingrese su correo" required>

                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" placeholder="Ingrese su contraseña" required>

                <button type="submit" class="btn btn-outline-custom">Iniciar sesión</button>
            </form>
            <p>¿No tienes una cuenta? <a href="registro.php">Regístrate aquí</a></p>

            <?php
            if (isset($_SESSION['error'])) {
                echo "<p class='error-message'>" . $_SESSION['error'] . "</p>";
                unset($_SESSION['error']);
            }
            ?>
        </div>
    </div>

    <script>
        function validateForm() {
            const correo = document.getElementById('correo').value;
            const password = document.getElementById('password').value;

            if (!correo || !password) {
                alert('Por favor complete ambos campos.');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>