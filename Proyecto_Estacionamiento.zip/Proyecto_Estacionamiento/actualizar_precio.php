<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['nombre']) || !isset($_SESSION['apellido'])) {
    header('Location: inicio_sesion.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sucursal_id = $_POST['sucursal_id'];
    $precio_por_hora = $_POST['precio_por_hora'];
    $precio_por_dia = $_POST['precio_por_dia'];
    $precio_por_semana = $_POST['precio_por_semana'];

    if (empty($sucursal_id) || !is_numeric($precio_por_hora) || !is_numeric($precio_por_dia) || !is_numeric($precio_por_semana)) {
        echo "Datos inválidos.";
        exit();
    }

    $sql = "UPDATE Precios SET precio_por_hora = ?, precio_por_dia = ?, precio_por_semana = ? WHERE sucursal_id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("dddi", $precio_por_hora, $precio_por_dia, $precio_por_semana, $sucursal_id);

    if ($stmt->execute()) {
        header('Location: precios.php?mensaje=Precios actualizados correctamente.');
    } else {
        echo "Error al actualizar los precios: " . $stmt->error;
    }

    $stmt->close();
    $conexion->close();
} else {
    header('Location: precios.php');
}
?>