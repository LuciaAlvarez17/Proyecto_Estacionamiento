<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['nombre']) || !isset($_SESSION['apellido'])) {
    header('Location: inicio_sesion.php');
    exit();
}

$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido'];

// Consultas actualizadas con JOIN para obtener el nombre de la sucursal
$ocupacionQuery = "SELECT Sucursales.nombre AS sucursal, COUNT(*) AS autos_estacionados 
                   FROM Estacionamientos 
                   JOIN Sucursales ON Estacionamientos.sucursal_id = Sucursales.id 
                   WHERE estado = 'ocupado' 
                   GROUP BY sucursal";

$ingresosQuery = "SELECT Sucursales.nombre AS sucursal, SUM(costo) AS ingresos_totales 
                  FROM Estacionamientos 
                  JOIN Sucursales ON Estacionamientos.sucursal_id = Sucursales.id 
                  WHERE estado IN ('ocupado', 'vacío') 
                  GROUP BY sucursal";

$costosQuery = "SELECT Sucursales.nombre AS sucursal, 
                       SUM(CASE WHEN estado = 'ocupado' THEN costo ELSE 0 END) AS costo_ocupado,
                       SUM(CASE WHEN estado = 'vacío' THEN costo ELSE 0 END) AS costo_vacio 
                FROM Estacionamientos 
                JOIN Sucursales ON Estacionamientos.sucursal_id = Sucursales.id 
                GROUP BY sucursal";

$ocupacionResult = $conexion->query($ocupacionQuery);
$ingresosResult = $conexion->query($ingresosQuery);
$costosResult = $conexion->query($costosQuery);

$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes - ParkWise</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="proyecto/dashboard.css">
</head>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Menú lateral -->
        <div class="bg-dark" id="sidebar-wrapper">
            <div class="sidebar-heading">
                <div class="logo-container">
                    <img src="img/logo.png" alt="ParkWise Logo" class="logo">
                </div>
            </div>
            <div class="list-group list-group-flush">
                <a href="dashboard.php" class="list-group-item list-group-item-action">Inicio</a>
                <a href="mis_sucursales.php" class="list-group-item list-group-item-action">Mis Sucursales</a>
                <a href="estacionamientos.php" class="list-group-item list-group-item-action">Estacionamientos</a>
                <a href="precios.php" class="list-group-item list-group-item-action">Precios</a>
                <a href="reportes.php" class="list-group-item list-group-item-action">Reportes</a>
                <a href="#" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#logoutModal">Cerrar Sesión</a>
                <img src="img/sky_dancer.gif" class="sky_dancer" alt="Sky Dancer">
            </div>
        </div>
        
        <!-- Contenido principal -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg">
                <div class="container-fluid">
                    <h1 class="navbar-brand">ParkWise</h1>
                    <div class="ml-auto">
                        <div class="card" style="width: 300px;">
                            <div class="card-body d-flex align-items-center">
                                <img src="img/usuario.png" alt="Usuario" class="img-fluid rounded-circle" style="width: 50px; height: 50px; margin-right: 10px;">
                                <h5 class="card-title mb-0"><?php echo "Hola, <br> $nombre $apellido" ?></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            <div class="container-fluid">
                <h1 class="mt-4">Reportes</h1>
                
                <!-- Sección de ocupación de estacionamientos -->
                <h2>Ocupación de Estacionamientos</h2>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Sucursal</th>
                            <th>Autos Estacionados</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $totalAutosEstacionados = 0;
                        while ($fila = $ocupacionResult->fetch_assoc()) { 
                            $totalAutosEstacionados += $fila['autos_estacionados'];
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($fila['sucursal']); ?></td>
                                <td><?php echo $fila['autos_estacionados']; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td><strong>Total</strong></td>
                            <td><strong><?php echo $totalAutosEstacionados; ?></strong></td>
                        </tr>
                    </tfoot>
                </table>

                <!-- Sección de ingresos por estacionamiento -->
                <h2>Ingresos por Sucursal</h2>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Sucursal</th>
                            <th>Ingresos Totales</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $totalIngresos = 0; // Para el resumen
                        while ($fila = $ingresosResult->fetch_assoc()) { 
                            $totalIngresos += $fila['ingresos_totales'];
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($fila['sucursal']); ?></td>
                                <td><?php echo "$" . number_format($fila['ingresos_totales'], 2); ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td><strong>Total</strong></td>
                            <td><strong><?php echo "$" . number_format($totalIngresos, 2); ?></strong></td>
                        </tr>
                    </tfoot>
                </table>

                <!-- Sección de costos de autos vacíos y ocupados -->
                <h2>Costos de Autos Vacíos y Ocupados</h2>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Sucursal</th>
                            <th>Costo Ocupado</th>
                            <th>Costo Vacío</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $totalCostoOcupado = 0;
                        $totalCostoVacio = 0;
                        while ($fila = $costosResult->fetch_assoc()) { 
                            $totalCostoOcupado += $fila['costo_ocupado'];
                            $totalCostoVacio += $fila['costo_vacio'];
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($fila['sucursal']); ?></td>
                                <td><?php echo "$" . number_format($fila['costo_ocupado'], 2); ?></td>
                                <td><?php echo "$" . number_format($fila['costo_vacio'], 2); ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td><strong>Total</strong></td>
                            <td><strong><?php echo "$" . number_format($totalCostoOcupado, 2); ?></strong></td>
                            <td><strong><?php echo "$" . number_format($totalCostoVacio, 2); ?></strong></td>
                        </tr>
                    </tfoot>
                </table>
                <h2>Visualización Gráfica</h2>
                <canvas id="ocupacionChart" width="400" height="200"></canvas>
                <canvas id="ingresosChart" width="400" height="200"></canvas>
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    // Datos para el gráfico de ocupación
                    const ocupacionLabels = [];
                    const ocupacionData = [];

                    <?php
                    $ocupacionResult->data_seek(0);
                    while ($fila = $ocupacionResult->fetch_assoc()) {
                        echo "ocupacionLabels.push('" . htmlspecialchars($fila['sucursal']) . "');";
                        echo "ocupacionData.push(" . $fila['autos_estacionados'] . ");";
                    }
                    ?>

                    const ocupacionCtx = document.getElementById('ocupacionChart').getContext('2d');
                    const ocupacionChart = new Chart(ocupacionCtx, {
                        type: 'bar',
                        data: {
                            labels: ocupacionLabels,
                            datasets: [{
                                label: 'Autos Estacionados',
                                data: ocupacionData,
                                backgroundColor: 'rgba(245, 197, 24, 0.2)',
                                borderColor: '#f5c518',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });

                    // Datos para el gráfico de ingresos
                    const ingresosLabels = [];
                    const ingresosData = [];

                    <?php
                    $ingresosResult->data_seek(0);
                    while ($fila = $ingresosResult->fetch_assoc()) {
                        echo "ingresosLabels.push('" . htmlspecialchars($fila['sucursal']) . "');";
                        echo "ingresosData.push(" . $fila['ingresos_totales'] . ");";
                    }
                    ?>

                    const ingresosCtx = document.getElementById('ingresosChart').getContext('2d');
                    const ingresosChart = new Chart(ingresosCtx, {
                        type: 'line',
                        data: {
                            labels: ingresosLabels,
                            datasets: [{
                                label: 'Ingresos Totales',
                                data: ingresosData,
                                backgroundColor: 'rgba(245, 197, 24, 0.2)',
                                borderColor: '#f5c518',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                </script>
            </div>
        </div>
    </div>

    <!-- Modal de confirmación de cierre de sesión -->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">¿Seguro que quieres cerrar sesión?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Haz clic en "Cerrar Sesión" si estás listo para terminar tu sesión actual.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                    <a href="logout.php" class="btn btn-outline-custom">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>