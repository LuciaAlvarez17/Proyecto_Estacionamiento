<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - ParkWise</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="registro.css">
</head>
<body>
    <div class="registro-container">
        <div class="registro-box">
            <div class="logo-container">
                <img src="img/logo.png" alt="ParkWise Logo" class="logo">
            </div>
            <form action="registrar.php" method="POST" onsubmit="return validateForm()">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="nombre">Nombre:</label>
                        <input type="text" id="nombre" name="nombre" class="form-control" placeholder="Ingrese su nombre" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="apellido">Apellido:</label>
                        <input type="text" id="apellido" name="apellido" class="form-control" placeholder="Ingrese su apellido" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono" class="form-control" placeholder="Ingrese su teléfono" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="correo">Correo electrónico:</label>
                        <input type="email" id="correo" name="correo" class="form-control" placeholder="Ingrese su correo" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="password">Contraseña:</label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="Ingrese su contraseña" required>
                    </div>
                </div>

                <div class="form-group col-md-8 mx-auto">
                    <label for="sucursales">Cantidad de Sucursales (máx. 10):</label>
                    <input type="number" id="sucursales" name="sucursales" class="form-control" min="1" max="10" placeholder="Ingrese la cantidad de sucursales" required oninput="updateSucursalInputs()">
                </div>

                <div id="sucursal-inputs" class="form-row"></div>

                <button type="submit" class="btn btn-outline-custom">Registrarse</button>
            </form>
            <p>¿Tienes una cuenta? <a href="inicio_sesion.php">Inicia Sesión aquí</a></p>

            <?php
            if (isset($_SESSION['error'])) {
                echo "<p class='error-message'>" . $_SESSION['error'] . "</p>";
                unset($_SESSION['error']);
            }
            ?>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script> 
    <script>
        function updateSucursalInputs() {
            const sucursalesInput = document.getElementById('sucursales');
            let sucursales = parseInt(sucursalesInput.value, 10);

            // Validar el valor de sucursales
            if (sucursales > 10) {
                sucursales = 10;
                sucursalesInput.value = sucursales;
            } else if (sucursales < 1 || isNaN(sucursales)) {
                sucursales = 0;
                sucursalesInput.value = '';
            }

            const sucursalInputsContainer = document.getElementById('sucursal-inputs');
            sucursalInputsContainer.innerHTML = '';

            // Crear un div para la fila actual
            let rowDiv = document.createElement('div');
            rowDiv.className = 'form-row espacios';

            for (let i = 1; i <= sucursales; i++) {
                const inputGroup = document.createElement('div');
                inputGroup.className = 'form-group col-md-2';

                inputGroup.innerHTML = `
                    <label for="espacios_sucursal_${i}">Sucursal ${i} (máx. 500):</label>
                    <input type="number" id="espacios_sucursal_${i}" name="espacios_sucursal[]" class="form-control" min="1" max="500" placeholder="Espacios" required oninput="validateEspacios(this)">
                `;

                rowDiv.appendChild(inputGroup);

                // Si hemos llegado a 5 columnas, añadir la fila al contenedor y crear una nueva fila
                if (i % 5 === 0) {
                    sucursalInputsContainer.appendChild(rowDiv);
                    rowDiv = document.createElement('div');
                    rowDiv.className = 'form-row espacios';
                }
            }

            // Si quedan inputs en la última fila, añadirlos al contenedor
            if (rowDiv.children.length > 0) {
                sucursalInputsContainer.appendChild(rowDiv);
            }
        }

        // Función para validar el input de espacios
        function validateEspacios(input) {
            const value = parseInt(input.value, 10);
            if (value > 500) {
                input.value = 500;
            } else if (value < 1) {
                input.value = '0';
            }
        }

        function validateForm() {
            const nombre = document.getElementById('nombre').value;
            const apellido = document.getElementById('apellido').value;
            const correo = document.getElementById('correo').value;
            const telefono = document.getElementById('telefono').value;
            const password = document.getElementById('password').value;
            const sucursales = document.getElementById('sucursales').value;

            if (!nombre || !apellido || !correo || !telefono || !password || !sucursales) {
                alert('Por favor complete todos los campos.');
                return false;
            }

            return true;
        }
    </script>
</body>
</html>