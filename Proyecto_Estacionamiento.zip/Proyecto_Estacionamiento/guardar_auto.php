<?php
include 'conexion.php';
session_start();

date_default_timezone_set('America/Argentina/Buenos_Aires');

$tipoVehiculo = $_POST['tipoVehiculo'];
$marcaModelo = $_POST['marcaModelo'];
$estado = $_POST['estado'];
$sucursal_id = $_POST['sucursal_id'];
$hora_salida = $_POST['horaSalida'];
$horaEntrada = date('Y-m-d H:i:s');

$conexion->begin_transaction();

try {
    $stmt = $conexion->prepare("INSERT INTO Estacionamientos (sucursal_id, tipo_vehiculo, marca_modelo, hora_entrada, hora_salida, estado) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $sucursal_id, $tipoVehiculo, $marcaModelo, $horaEntrada, $hora_salida, $estado);
    if (!$stmt->execute()) {
        throw new Exception("Error al agregar el auto.");
    }

    $stmt_update = $conexion->prepare("UPDATE Sucursales SET espacios_disponibles = espacios_disponibles - 1 WHERE id = ? AND espacios_disponibles > 0");
    $stmt_update->bind_param("i", $sucursal_id);
    if (!$stmt_update->execute()) {
        throw new Exception("Error al actualizar los espacios disponibles.");
    }

    $conexion->commit();
    header('Location: estacionamientos.php');
} catch (Exception $e) {
    $conexion->rollback();
    echo $e->getMessage();
}

$stmt->close();
$stmt_update->close();
?>
