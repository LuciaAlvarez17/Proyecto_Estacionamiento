<?php
session_start();
include 'conexion.php';

$usuario_id = $_SESSION['usuario_id'];

$sql_count = "SELECT COUNT(*) AS total FROM Sucursales WHERE usuario_id = ?";
$stmt_count = $conexion->prepare($sql_count);
$stmt_count->bind_param("i", $usuario_id);
$stmt_count->execute();
$result_count = $stmt_count->get_result();
$row = $result_count->fetch_assoc();
$total_sucursales = $row['total'];

if ($total_sucursales >= 10) {
    echo "No se puede crear más sucursales. Has alcanzado el límite de 10.";
    exit();
}

$nombre = $_POST['nombre'];
$ubicacion = $_POST['ubicacion'];
$espacios_disponibles = $_POST['espacios'];

if ($espacios_disponibles > 500) {
    echo "El número de espacios disponibles no puede exceder 500.";
    exit();
}

$sql_insert = "INSERT INTO Sucursales (usuario_id, nombre, ubicacion, espacios_disponibles) VALUES (?, ?, ?, ?)";
$stmt_insert = $conexion->prepare($sql_insert);
$stmt_insert->bind_param("issi", $usuario_id, $nombre, $ubicacion, $espacios_disponibles);

if ($stmt_insert->execute()) {
    echo "Sucursal creada exitosamente.";
    header('Location: mis_sucursales.php');
    exit();
} else {
    echo "Error al crear la sucursal: " . $stmt_insert->error;
}

$stmt_count->close();
$stmt_insert->close();
$conexion->close();
?>
