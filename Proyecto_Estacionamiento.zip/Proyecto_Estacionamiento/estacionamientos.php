<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['nombre']) || !isset($_SESSION['apellido']) || !isset($_SESSION['usuario_id'])) {
    header('Location: inicio_sesion.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido'];

// Obtener las sucursales relacionadas con el usuario logueado
$stmt = $conexion->prepare("SELECT id, nombre FROM Sucursales WHERE usuario_id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result_sucursales = $stmt->get_result();

function calcularCosto($horaEntrada, $horaSalida, $precioPorHora, $precioPorDia, $precioPorSemana) {
    $fechaEntrada = new DateTime($horaEntrada);
    $fechaSalida = new DateTime($horaSalida);
    
    $intervalo = $fechaEntrada->diff($fechaSalida);
    $dias = (int)$intervalo->format('%d');
    $horas = (int)$intervalo->format('%h') + ($dias * 24);
    $semanas = (int)($dias / 7);
    
    $costoTotal = 0;

    if ($semanas > 0) {
        $costoTotal += $semanas * $precioPorSemana;
        $dias -= $semanas * 7;
    }
    
    if ($dias > 0) {
        $costoTotal += $dias * $precioPorDia;
        $horas -= $dias * 24;
    }

    if ($horas > 0) {
        $costoTotal += $horas * $precioPorHora;
    }

    return $costoTotal;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estacionamientos - ParkWise</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="proyecto/dashboard.css">
</head>
<body>
<div class="d-flex" id="wrapper">

    <!-- Menú lateral -->
    <div class="bg-dark" id="sidebar-wrapper">
        <div class="sidebar-heading">
            <div class="logo-container">
                <img src="img/logo.png" alt="ParkWise Logo" class="logo">
            </div>
        </div>
        <div class="list-group list-group-flush">
            <a href="dashboard.php" class="list-group-item list-group-item-action">Inicio</a>
            <a href="mis_sucursales.php" class="list-group-item list-group-item-action">Mis Sucursales</a>
            <a href="estacionamientos.php" class="list-group-item list-group-item-action">Estacionamientos</a>
            <a href="precios.php" class="list-group-item list-group-item-action">Precios</a>
            <a href="reportes.php" class="list-group-item list-group-item-action">Reportes</a>
            <a href="#" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#logoutModal">Cerrar Sesión</a>
            <img src="img/sky_dancer.gif" class="sky_dancer" alt="Sky Dancer">
        </div>
    </div>

    <!-- Contenido principal -->
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <h1 class="navbar-brand">ParkWise</h1>
                <div class="ml-auto">
                    <div class="card" style="width: 300px;">
                        <div class="card-body d-flex align-items-center">
                            <img src="img/usuario.png" alt="Usuario" class="img-fluid rounded-circle" style="width: 50px; height: 50px; margin-right: 10px;">
                            <h5 class="card-title mb-0"><?php echo "Hola, <br> $nombre $apellido" ?></h5>
                        </div>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <h1 class="mt-4">Gestión de Estacionamientos</h1>
            
            <!-- Solapas (Tabs) para cada sucursal -->
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <?php
                $first = true;
                while ($sucursal = $result_sucursales->fetch_assoc()) {
                    $sucursal_id = $sucursal['id'];
                    $sucursal_nombre = $sucursal['nombre'];
                ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo $first ? 'active' : ''; ?>" id="tab-<?php echo $sucursal_id; ?>" data-toggle="tab" href="#sucursal-<?php echo $sucursal_id; ?>" role="tab" aria-controls="sucursal-<?php echo $sucursal_id; ?>" aria-selected="true"><?php echo $sucursal_nombre; ?></a>
                </li>
                <?php
                    $first = false;
                }
                ?>
            </ul>

            <!-- Contenido de las solapas -->
            <div class="tab-content" id="myTabContent">
                <?php
                $first = true;
                $result_sucursales->data_seek(0);
                while ($sucursal = $result_sucursales->fetch_assoc()) {
                    $sucursal_id = $sucursal['id'];
                ?>
                <div class="tab-pane fade <?php echo $first ? 'show active' : ''; ?>" id="sucursal-<?php echo $sucursal_id; ?>" role="tabpanel" aria-labelledby="tab-<?php echo $sucursal_id; ?>">
                    <button type="button" class="btn btn-outline-custom" data-toggle="modal" data-target="#agregarAutoModal-<?php echo $sucursal_id; ?>" >Agregar Auto</button>

                    <!-- Tabla de estacionamientos -->
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tipo de Vehículo</th>
                                <th>Marca y Modelo</th>
                                <th>Hora de Entrada</th>
                                <th>Hora de Salida</th>
                                <th>Costo</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Obtener los precios por hora, día y semana de la sucursal
                            $stmt_precio = $conexion->prepare("SELECT precio_por_hora, precio_por_dia, precio_por_semana FROM Precios WHERE sucursal_id = ?");
                            $stmt_precio->bind_param("i", $sucursal_id);
                            $stmt_precio->execute();
                            $result_precio = $stmt_precio->get_result();
                            $precios = $result_precio->fetch_assoc();
                            $precio_por_hora = $precios['precio_por_hora'];
                            $precio_por_dia = $precios['precio_por_dia'];
                            $precio_por_semana = $precios['precio_por_semana'];

                            $stmt_estacionamientos = $conexion->prepare("SELECT * FROM Estacionamientos WHERE sucursal_id = ? AND estado = 'ocupado'");
                            $stmt_estacionamientos->bind_param("i", $sucursal_id);
                            $stmt_estacionamientos->execute();
                            $result_estacionamientos = $stmt_estacionamientos->get_result();

                             while ($espacio = $result_estacionamientos->fetch_assoc()) {
                                $costo = 0; 
                                if ($espacio['hora_entrada'] && $espacio['hora_salida']) {
                                    $costo = calcularCosto($espacio['hora_entrada'], $espacio['hora_salida'], $precio_por_hora, $precio_por_dia, $precio_por_semana);
                                }
                                $stmt_update = $conexion->prepare("UPDATE Estacionamientos SET costo = ? WHERE id = ?");
                                $stmt_update->bind_param("di", $costo, $espacio['id']);
                                $stmt_update->execute();
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($espacio['tipo_vehiculo']); ?></td>
                                <td><?php echo htmlspecialchars($espacio['marca_modelo']); ?></td>
                                <td><?php echo $espacio['hora_entrada'] ? date('Y-m-d H:i', strtotime($espacio['hora_entrada'])) : 'No reservado'; ?></td>
                                <td><?php echo $espacio['hora_salida'] ? date('Y-m-d H:i', strtotime($espacio['hora_salida'])) : 'No registrado'; ?></td>
                                <td><?php echo number_format($costo, 2); ?> $</td>
                                <td><?php echo htmlspecialchars($espacio['estado']); ?></td>
                                <td>
                                    <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editarAutoModal-<?php echo $espacio['id']; ?>" 
                                            data-id="<?php echo $espacio['id']; ?>" 
                                            data-tipo="<?php echo htmlspecialchars($espacio['tipo_vehiculo']); ?>" 
                                            data-marca="<?php echo htmlspecialchars($espacio['marca_modelo']); ?>" 
                                            data-hora-salida="<?php echo $espacio['hora_salida']; ?>" 
                                            data-estado="<?php echo htmlspecialchars($espacio['estado']); ?>">
                                        Editar
                                    </button>
                                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#eliminarAutoModal-<?php echo $espacio['id']; ?>" 
                                            data-id="<?php echo $espacio['id']; ?>" 
                                            data-marca="<?php echo htmlspecialchars($espacio['marca_modelo']); ?>">
                                        Eliminar
                                    </button>
                                </td>
                            </tr>

                            <!-- Modal de edición de auto -->
                            <div class="modal fade" id="editarAutoModal-<?php echo $espacio['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editarAutoModalLabel-<?php echo $espacio['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <form action="actualizar_auto.php" method="post">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editarAutoModalLabel-<?php echo $espacio['id']; ?>">Editar Auto</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="id" value="<?php echo $espacio['id']; ?>">
                                                <div class="form-group">
                                                    <label for="tipoVehiculo">Tipo de Vehículo</label>
                                                    <input type="text" class="form-control" name="tipoVehiculo" value="<?php echo htmlspecialchars($espacio['tipo_vehiculo']); ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="marcaModelo">Marca y Modelo</label>
                                                    <input type="text" class="form-control" name="marcaModelo" value="<?php echo htmlspecialchars($espacio['marca_modelo']); ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="horaSalida">Hora de Salida</label>
                                                    <input type="datetime-local" class="form-control" name="horaSalida" value="<?php echo $espacio['hora_salida'] ? date('Y-m-d\TH:i', strtotime($espacio['hora_salida'])) : ''; ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="estado">Estado</label>
                                                    <select class="form-control" name="estado">
                                                        <option value="vacío" <?php echo $espacio['estado'] == 'vacío' ? 'selected' : ''; ?>>Vacío</option>
                                                        <option value="ocupado" <?php echo $espacio['estado'] == 'ocupado' ? 'selected' : ''; ?>>Ocupado</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-outline-custom">Guardar cambios</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal de eliminación de auto -->
                            <div class="modal fade" id="eliminarAutoModal-<?php echo $espacio['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="eliminarAutoModalLabel-<?php echo $espacio['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <form action="eliminar_auto.php" method="post">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="eliminarAutoModalLabel-<?php echo $espacio['id']; ?>">Eliminar Auto</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="id" value="<?php echo $espacio['id']; ?>">
                                                <p>¿Estás seguro de que deseas eliminar el auto <strong><?php echo htmlspecialchars($espacio['marca_modelo']); ?></strong>?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-outline-custom">Eliminar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php
                    $first = false;
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Modal para agregar auto -->
    <?php
    $result_sucursales->data_seek(0);
    while ($sucursal = $result_sucursales->fetch_assoc()) {
        $sucursal_id = $sucursal['id'];
    ?>
        <div class="modal fade" id="agregarAutoModal-<?php echo $sucursal_id; ?>" tabindex="-1" role="dialog" aria-labelledby="agregarAutoModalLabel-<?php echo $sucursal_id; ?>" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="agregarAutoModalLabel-<?php echo $sucursal_id; ?>">Agregar Auto a <?php echo $sucursal['nombre']; ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="guardar_auto.php" method="POST">
                        <input type="hidden" name="sucursal_id" value="<?php echo $sucursal_id; ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="tipoVehiculo-<?php echo $sucursal_id; ?>">Tipo de Vehículo</label>
                                <input type="text" class="form-control" id="tipoVehiculo-<?php echo $sucursal_id; ?>" name="tipoVehiculo" required>
                            </div>
                            <div class="form-group">
                                <label for="marcaModelo-<?php echo $sucursal_id; ?>">Marca y Modelo</label>
                                <input type="text" class="form-control" id="marcaModelo-<?php echo $sucursal_id; ?>" name="marcaModelo" required>
                            </div>
                            <div class="form-group">
                                <label for="horaSalida-<?php echo $sucursal_id; ?>">Hora de Salida</label>
                                <input type="datetime-local" class="form-control" id="horaSalida-<?php echo $sucursal_id; ?>" name="horaSalida">
                            </div>
                            <div class="form-group">
                                <label for="estado-<?php echo $sucursal_id; ?>">Estado</label>
                                <select class="form-control" id="estado-<?php echo $sucursal_id; ?>" name="estado">
                                    <option value="vacío">Vacío</option>
                                    <option value="ocupado">Ocupado</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-outline-custom">Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php
    }
    ?>

    <!-- Modal de confirmación de cierre de sesión -->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">¿Seguro que quieres cerrar sesión?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Haz clic en "Cerrar Sesión" si estás listo para terminar tu sesión actual.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-custom" data-dismiss="modal">Cancelar</button>
                    <a href="logout.php" class="btn btn-outline-custom">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>